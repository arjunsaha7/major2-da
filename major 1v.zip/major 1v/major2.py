import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# load csv file
df = pd.read_csv("StudentsPerformance.csv")

# index start from 1 insted of 0
df.index = np.arange(1, len(df) + 1)

# rename some col names
df = df.rename(columns={
    "math score": "Math",
    "reading score": "Read",
    "writing score": "Write",
    "gender": "Sex"
})

# making student id bcz csv dont have name
df["StudentID"] = ["S" + str(i) for i in range(1, len(df) + 1)]

subjects = ["Math", "Read", "Write"]

print("\nData loaded\n")
print(df.head())

# subject wise info
subject_mean = df[subjects].mean()
subject_max = df[subjects].max()
subject_min = df[subjects].min()

print("\navrage of subjects\n")
print(subject_mean)

print("\nhighest marks\n")
print(subject_max)

print("\nlowest marks\n")
print(subject_min)

# total and avg of students
df["TotalMarks"] = df[subjects].sum(axis=1)
df["AvgMarks"] = df[subjects].mean(axis=1)

print("\nstudent details\n")
print(df[["StudentID","Sex","TotalMarks","AvgMarks"]].head())

# find topper
best = df.loc[df["TotalMarks"].idxmax()]

print("\ntopper details\n")
print("id :", best["StudentID"])
print("gender :", best["Sex"])
print("total :", best["TotalMarks"])

# consistancy
df["Stability"] = df[subjects].std(axis=1)

print("\nstudent consistancy\n")
print(df[["StudentID","Stability"]].head())

# subject dificult
difficulty_index = 100 - df[subjects].mean()

print("\nsubject dificult level\n")
print(difficulty_index)

# trend of student marks
df["Change"] = df["AvgMarks"].diff()

print("\nmarks change\n")
print(df[["StudentID","Change"]].head())

# fake attendence
np.random.seed(1)
df["Attend"] = np.random.randint(50, 100, len(df))

relation = df["Attend"].corr(df["AvgMarks"])
print("\nattendence vs marks reltion :", relation)

# drop out logic
def predict_dropout(avg, spread):
    if avg < 40 or spread > 20:
        return "High"
    elif avg < 60:
        return "Medium"
    else:
        return "Low"

df["RiskLevel"] = df.apply(lambda r: predict_dropout(r["AvgMarks"], r["Stability"]), axis=1)

print("\ndropout risk\n")
print(df[["StudentID","AvgMarks","Stability","RiskLevel"]].head())

# grade cal
def give_grade(x):
    if x >= 80:
        return "A"
    elif x >= 60:
        return "B"
    elif x >= 40:
        return "C"
    else:
        return "Fail"

df["Result"] = df["AvgMarks"].apply(give_grade)

print("\nfinal grades\n")
print(df[["StudentID","AvgMarks","Result"]].head())

# graphs
plt.figure(figsize=(8,5))
plt.plot(df["AvgMarks"].head(30))
plt.title("avg marks trend")
plt.ylabel("marks")
plt.show()

plt.figure(figsize=(8,5))
difficulty_index.plot(kind="bar")
plt.title("subject dificult")
plt.ylabel("dificult level")
plt.show()

plt.figure(figsize=(6,4))
plt.boxplot(df["Stability"])
plt.title("student consistancy")
plt.ylabel("std dev")
plt.show()

plt.figure(figsize=(8,5))
plt.bar(df["StudentID"].head(10), df["AvgMarks"].head(10))
plt.xticks(rotation=45)
plt.title("student marks")
plt.ylabel("avg marks")
plt.show()